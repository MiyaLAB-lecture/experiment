﻿Public Class Form1
    Const port As Integer = 20000 ' ポート番号
    Dim enc As System.Text.Encoding = System.Text.Encoding.Default ' 文字コードに「Shift-JIS」を指定
    Dim sHandle As Long = -1 ' サーバハンドル
    Dim cHandle As Long = -1 ' クライアントハンドル

    ' 「待機」ボタンが押された
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' リッスンおよび接続が行われていないとき
        If sHandle = -1 AndAlso cHandle = -1 Then
            Try
                sHandle = TcpSockets1.OpenAsServer(port) ' サーバとして動作
                WriteMessage("待機中 !")
            Catch ex As Exception ' 例外がスローされたとき
                ' エラーメッセージを出力
                WriteMessage("Error: " & ex.Message)
            End Try
        End If

    End Sub

    ' ステータス／受信メッセージの表示
    Public Sub WriteMessage(ByVal msg As String)
        TextBox2.Invoke(Sub() TextBox2.Text = TextBox2.Text & msg & vbCrLf)
    End Sub

    ' 「接続」ボタンが押された
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' リッスンおよび接続が行われていないとき
        If sHandle = -1 AndAlso cHandle = -1 Then
            Try
                Dim host As String = TextBox1.Text
                ' クライアントとして動作
                cHandle = TcpSockets1.OpenAsClient(host, port)
                WriteMessage("接続中 !")
            Catch ex As Exception ' 例外がスローされたとき
                ' エラーメッセージを出力
                WriteMessage("Error: " & ex.Message)
            End Try
        End If

    End Sub

    ' 「切断」ボタンが押された
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If sHandle <> -1 Then ' サーバとして動作しているとき
            TcpSockets1.Close(sHandle) ' リッスンをやめる
            sHandle = -1
            WriteMessage("待機終了 !")
        End If
        If cHandle <> -1 Then ' クライアントとして動作しているとき
            TcpSockets1.Close(cHandle) ' リモートとの通信を切断する
            WriteMessage("切断 !")
        End If
    End Sub

    ' 「送信」ボタンが押された
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If cHandle <> -1 Then ' リモートに接続しているとき
            Dim msg As String = TextBox3.Text
            Dim bytes As Byte() = enc.GetBytes(msg) ' 文字列をバイト配列に変換
            Try
                TcpSockets1.Send(cHandle, bytes) ' メッセージ送信
            Catch ex As Exception ' 例外がスローされたとき
                ' エラーメッセージを出力
                WriteMessage("Error: " & ex.Message)
            End Try
        End If
    End Sub
    ' Acceptイベントが発生した
    Private Sub TcpSockets1_Accept(ByVal sender As System.Object, ByVal e As Experiment.TcpSocket.AcceptEventArgs) Handles TcpSockets1.Accept
        ' NOTE: このロジックでは２回以上のアクセプトに対応できない

        cHandle = e.ClientHandle
        WriteMessage("受付 !")
    End Sub

    ' Connectイベントが発生した
    Private Sub TcpSockets1_Connect(ByVal sender As System.Object, ByVal e As Experiment.TcpSocket.ConnectEventArgs) Handles TcpSockets1.Connect
        WriteMessage("接続完了 !")
    End Sub

    ' Disconnectイベントが発生した
    Private Sub TcpSockets1_Disconnect(ByVal sender As System.Object, ByVal e As Experiment.TcpSocket.DisconnectEventArgs) Handles TcpSockets1.Disconnect
        cHandle = -1
        WriteMessage("切断されました !")
    End Sub

    ' DataReceiveイベントが発生した
    Private Sub TcpSockets1_DataReceive(ByVal sender As System.Object, ByVal e As Experiment.TcpSocket.DataReceiveEventArgs) Handles TcpSockets1.DataReceive
        Dim msg As String = enc.GetString(e.Data) ' バイト配列を文字列に変換
        WriteMessage("受信> " & msg)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
